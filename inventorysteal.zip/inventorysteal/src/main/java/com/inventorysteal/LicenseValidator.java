package com.inventorysteal;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import java.util.logging.Logger;

public class LicenseValidator {

    public static boolean verify(JavaPlugin plugin, String apiUrl, String pluginId, String licenseKey) {
        Logger logger = plugin.getLogger();
        
        // Agar user ne key nahi daali hai
        if (licenseKey == null || licenseKey.isEmpty() || licenseKey.equals("YOUR_KEY_HERE")) {
            logger.severe("==========================================");
            logger.severe("LICENSE KEY NOT FOUND!");
            logger.severe("Please enter your license key in config.yml");
            logger.severe("==========================================");
            return false;
        }

        // 1. Get or generate the Server Fingerprint (HWID)
        String serverUUID = getServerFingerprint(plugin);
        
        logger.info("Verifying license with server...");
        
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000); // 5 seconds timeout
            
            // Create JSON payload manually
            String jsonInputString = String.format(
                "{\"plugin_id\": \"%s\", \"license_key\": \"%s\", \"hwid\": \"%s\"}",
                pluginId, licenseKey, serverUUID
            );
            
            // Send payload
            try(OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            
            // Read response
            BufferedReader br = new BufferedReader(new InputStreamReader(
                (responseCode >= 200 && responseCode <= 299) ? connection.getInputStream() : connection.getErrorStream(), "utf-8"
            ));
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            
            String responseStr = response.toString();
            
            // Basic String checking to find if valid is true.
            if (responseCode == 200 && responseStr.contains("\"valid\": true")) {
                logger.info("==========================================");
                logger.info("License Verified Successfully!");
                logger.info("Thank you for supporting the developer.");
                logger.info("==========================================");
                return true;
            } else {
                logger.severe("==========================================");
                logger.severe("LICENSE VERIFICATION FAILED!");
                
                // Try to extract message
                if (responseStr.contains("\"message\":")) {
                    String[] parts = responseStr.split("\"message\":");
                    if (parts.length > 1) {
                        String msg = parts[1].split("\"")[1]; // Extract string between quotes
                        logger.severe("Reason: " + msg);
                    }
                }
                logger.severe("==========================================");
                return false;
            }
            
        } catch (Exception e) {
            logger.severe("Failed to connect to license server. Error: " + e.getMessage());
            return false; // Blocks access if server is down or unreachable
        }
    }

    /**
     * Generates a unique UUID for this server/plugin installation.
     */
    private static String getServerFingerprint(JavaPlugin plugin) {
        FileConfiguration config = plugin.getConfig();
        String uuidPath = "system.server_fingerprint";
        
        String currentFingerprint = config.getString(uuidPath);
        if (currentFingerprint == null || currentFingerprint.isEmpty()) {
            // First time running the plugin, generate a unique ID
            String newUUID = UUID.randomUUID().toString();
            config.set(uuidPath, newUUID);
            plugin.saveConfig();
            return newUUID;
        }
        return currentFingerprint;
    }
}
