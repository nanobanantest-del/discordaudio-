package com.inventorysteal.config;

import com.inventorysteal.InventoryStealPlugin;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Manages all player-facing messages from {@code messages.yml}.
 *
 * <p>All values returned are fully colour-translated.
 * Placeholder substitution is done by the caller via {@link #format}.
 */
public class MessagesManager {

    private static final Logger LOGGER = Logger.getLogger(MessagesManager.class.getName());

    private final InventoryStealPlugin plugin;
    private FileConfiguration messages;
    private String prefix;

    public MessagesManager(InventoryStealPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    // -------------------------------------------------------------------------
    // Loading
    // -------------------------------------------------------------------------

    /** Load / reload messages.yml from disk, falling back to the bundled default. */
    public void reload() {
        File file = new File(plugin.getDataFolder(), "messages.yml");

        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }

        messages = YamlConfiguration.loadConfiguration(file);

        // Merge any missing keys from the bundled default
        InputStream defaultStream = plugin.getResource("messages.yml");
        if (defaultStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            messages.setDefaults(defaults);
        }

        prefix = colorize(messages.getString("prefix", "&8[&6InventorySteal&8] &r"));
    }

    // -------------------------------------------------------------------------
    // Retrieval
    // -------------------------------------------------------------------------

    /**
     * Retrieve a message, applying the plugin prefix and colour codes.
     *
     * @param key dot-separated YAML path
     * @return translated message
     */
    public String get(String key) {
        String value = messages.getString(key, "&cMissing message: " + key);
        return prefix + colorize(value);
    }

    /**
     * Retrieve a message without the prefix.
     *
     * @param key dot-separated YAML path
     * @return translated message without prefix
     */
    public String getRaw(String key) {
        return colorize(messages.getString(key, "&cMissing message: " + key));
    }

    /**
     * Retrieve a list of strings, colour-translated.
     *
     * @param key dot-separated YAML path
     * @return list of translated lines (empty list if key absent)
     */
    public List<String> getList(String key) {
        List<String> raw = messages.getStringList(key);
        return raw.stream().map(this::colorize).toList();
    }

    // -------------------------------------------------------------------------
    // Placeholder substitution
    // -------------------------------------------------------------------------

    /**
     * Format a message by substituting {@code {key}} placeholders.
     *
     * <pre>
     * format("team.created", Map.of("team", "Warriors"))
     * // → "[InventorySteal] Team Warriors created successfully!"
     * </pre>
     *
     * @param key          YAML key (with prefix)
     * @param replacements map of placeholder name → replacement value
     * @return formatted, colour-translated message
     */
    public String format(String key, Map<String, String> replacements) {
        String msg = get(key);
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            msg = msg.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return msg;
    }

    /**
     * Format a raw message (no prefix) with placeholders.
     *
     * @param key          YAML key (no prefix applied)
     * @param replacements placeholder map
     * @return formatted message
     */
    public String formatRaw(String key, Map<String, String> replacements) {
        String msg = getRaw(key);
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            msg = msg.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return msg;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Translate {@code &} colour codes.
     *
     * @param text raw text
     * @return translated text
     */
    private String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    public String getPrefix() { return prefix; }
}
