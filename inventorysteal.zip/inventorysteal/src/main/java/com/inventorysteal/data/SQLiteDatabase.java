package com.inventorysteal.data;

import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;

import java.io.File;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;

/**
 * SQLite implementation of {@link Database}.
 *
 * <p>Uses a single JDBC connection with WAL mode for performance.
 * All calls run on the calling thread — typically the main server thread.
 * The SQLite JDBC driver is shaded into the plugin JAR.
 */
public class SQLiteDatabase implements Database {

    private static final Logger LOGGER = Logger.getLogger(SQLiteDatabase.class.getName());

    private final File dbFile;
    private Connection connection;

    /**
     * @param dbFile path to the .db file (created if absent)
     */
    public SQLiteDatabase(File dbFile) {
        this.dbFile = dbFile;
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void initialize() throws Exception {
        // Ensure parent directory exists
        dbFile.getParentFile().mkdirs();

        Class.forName("org.sqlite.JDBC");
        connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

        // Enable WAL journal mode for better concurrent read performance
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL;");
            st.execute("PRAGMA foreign_keys=ON;");
        }

        createTables();
        LOGGER.info("SQLite database initialised at " + dbFile.getAbsolutePath());
    }

    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            LOGGER.warning("Error closing SQLite connection: " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Schema
    // -------------------------------------------------------------------------

    private void createTables() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS teams (" +
                "  id TEXT PRIMARY KEY," +
                "  name TEXT NOT NULL COLLATE NOCASE UNIQUE," +
                "  leader_id TEXT NOT NULL," +
                "  storage_slots INTEGER NOT NULL DEFAULT 27," +
                "  max_health_bonus REAL NOT NULL DEFAULT 0.0" +
                ");"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_members (" +
                "  team_id TEXT NOT NULL," +
                "  player_uuid TEXT NOT NULL," +
                "  joined_at TEXT NOT NULL," +
                "  PRIMARY KEY (team_id, player_uuid)," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ");"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_invites (" +
                "  team_id TEXT NOT NULL," +
                "  invited_player TEXT NOT NULL," +
                "  invited_by TEXT NOT NULL," +
                "  expires_at TEXT NOT NULL," +
                "  PRIMARY KEY (team_id, invited_player)," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ");"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_inventories (" +
                "  team_id TEXT PRIMARY KEY," +
                "  player_inventory TEXT," +
                "  ender_chest TEXT," +
                "  team_storage TEXT," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ");"
            );
            // Index for member lookups
            st.executeUpdate(
                "CREATE INDEX IF NOT EXISTS idx_members_player " +
                "ON team_members(player_uuid);"
            );
        }
    }

    // -------------------------------------------------------------------------
    // Team CRUD
    // -------------------------------------------------------------------------

    @Override
    public void createTeam(Team team) {
        String sql = "INSERT INTO teams(id, name, leader_id, storage_slots, max_health_bonus) " +
                     "VALUES (?, ?, ?, ?, ?);";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, team.getId().toString());
            ps.setString(2, team.getName());
            ps.setString(3, team.getLeaderId().toString());
            ps.setInt(4, team.getStorageSlots());
            ps.setDouble(5, team.getMaxHealthBonus());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to create team " + team.getName() + ": " + e.getMessage());
        }
    }

    @Override
    public Team getTeam(UUID teamId) {
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus " +
                     "FROM teams WHERE id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team " + teamId + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public Team getTeamByName(String name) {
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus " +
                     "FROM teams WHERE name = ? COLLATE NOCASE;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team by name " + name + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public Team getTeamByMember(UUID playerUUID) {
        String sql = "SELECT t.id, t.name, t.leader_id, t.storage_slots, t.max_health_bonus " +
                     "FROM teams t INNER JOIN team_members m ON t.id = m.team_id " +
                     "WHERE m.player_uuid = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUUID.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team for member " + playerUUID + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Team> getAllTeams() {
        List<Team> teams = new ArrayList<>();
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus FROM teams;";
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                teams.add(buildTeam(rs));
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load all teams: " + e.getMessage());
        }
        return teams;
    }

    @Override
    public void updateTeam(Team team) {
        String sql = "UPDATE teams SET name = ?, leader_id = ?, storage_slots = ?, " +
                     "max_health_bonus = ? WHERE id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, team.getName());
            ps.setString(2, team.getLeaderId().toString());
            ps.setInt(3, team.getStorageSlots());
            ps.setDouble(4, team.getMaxHealthBonus());
            ps.setString(5, team.getId().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to update team " + team.getName() + ": " + e.getMessage());
        }
    }

    @Override
    public void deleteTeam(UUID teamId) {
        String sql = "DELETE FROM teams WHERE id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to delete team " + teamId + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Member management
    // -------------------------------------------------------------------------

    @Override
    public void addMember(UUID teamId, UUID playerUUID) {
        String sql = "INSERT OR IGNORE INTO team_members(team_id, player_uuid, joined_at) " +
                     "VALUES (?, ?, ?);";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerUUID.toString());
            ps.setString(3, Instant.now().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to add member " + playerUUID + " to team " + teamId + ": " + e.getMessage());
        }
    }

    @Override
    public void removeMember(UUID teamId, UUID playerUUID) {
        String sql = "DELETE FROM team_members WHERE team_id = ? AND player_uuid = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerUUID.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to remove member " + playerUUID + ": " + e.getMessage());
        }
    }

    @Override
    public List<UUID> getMembers(UUID teamId) {
        List<UUID> members = new ArrayList<>();
        String sql = "SELECT player_uuid FROM team_members WHERE team_id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                members.add(UUID.fromString(rs.getString("player_uuid")));
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load members for team " + teamId + ": " + e.getMessage());
        }
        return members;
    }

    // -------------------------------------------------------------------------
    // Invite management
    // -------------------------------------------------------------------------

    @Override
    public void addInvite(PendingInvite invite) {
        String sql = "INSERT OR REPLACE INTO team_invites(team_id, invited_player, invited_by, expires_at) " +
                     "VALUES (?, ?, ?, ?);";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, invite.getTeamId().toString());
            ps.setString(2, invite.getInvitedPlayer().toString());
            ps.setString(3, invite.getInvitedBy().toString());
            ps.setString(4, invite.getExpiresAt().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to add invite: " + e.getMessage());
        }
    }

    @Override
    public void removeInvite(UUID teamId, UUID invitedPlayer) {
        String sql = "DELETE FROM team_invites WHERE team_id = ? AND invited_player = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, invitedPlayer.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to remove invite: " + e.getMessage());
        }
    }

    @Override
    public Map<UUID, PendingInvite> getInvites(UUID teamId) {
        Map<UUID, PendingInvite> invites = new HashMap<>();
        String sql = "SELECT team_id, invited_player, invited_by, expires_at " +
                     "FROM team_invites WHERE team_id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                UUID invitedPlayer = UUID.fromString(rs.getString("invited_player"));
                UUID invitedBy = UUID.fromString(rs.getString("invited_by"));
                Instant expiresAt = Instant.parse(rs.getString("expires_at"));
                PendingInvite invite = new PendingInvite(teamId, invitedPlayer, invitedBy, expiresAt);
                invites.put(invitedPlayer, invite);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load invites for team " + teamId + ": " + e.getMessage());
        }
        return invites;
    }

    // -------------------------------------------------------------------------
    // Inventory storage
    // -------------------------------------------------------------------------

    @Override
    public void saveTeamInventory(UUID teamId, String playerInventory,
                                  String enderChestData, String teamStorageData) {
        String sql = "INSERT INTO team_inventories(team_id, player_inventory, ender_chest, team_storage) " +
                     "VALUES (?, ?, ?, ?) " +
                     "ON CONFLICT(team_id) DO UPDATE SET " +
                     "  player_inventory = excluded.player_inventory," +
                     "  ender_chest = excluded.ender_chest," +
                     "  team_storage = excluded.team_storage;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerInventory);
            ps.setString(3, enderChestData);
            ps.setString(4, teamStorageData);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save team inventory for " + teamId + ": " + e.getMessage());
        }
    }

    @Override
    public String[] getTeamInventory(UUID teamId) {
        String sql = "SELECT player_inventory, ender_chest, team_storage " +
                     "FROM team_inventories WHERE team_id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new String[]{
                    rs.getString("player_inventory"),
                    rs.getString("ender_chest"),
                    rs.getString("team_storage")
                };
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team inventory for " + teamId + ": " + e.getMessage());
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Upgrades
    // -------------------------------------------------------------------------

    @Override
    public void saveStorageSize(UUID teamId, int slots) {
        String sql = "UPDATE teams SET storage_slots = ? WHERE id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, slots);
            ps.setString(2, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save storage size for " + teamId + ": " + e.getMessage());
        }
    }

    @Override
    public void saveMaxHealthBonus(UUID teamId, double bonus) {
        String sql = "UPDATE teams SET max_health_bonus = ? WHERE id = ?;";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDouble(1, bonus);
            ps.setString(2, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save health bonus for " + teamId + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /**
     * Construct a {@link Team} from the current row of a result set and load its members.
     */
    private Team buildTeam(ResultSet rs) throws SQLException {
        UUID id = UUID.fromString(rs.getString("id"));
        String name = rs.getString("name");
        UUID leaderId = UUID.fromString(rs.getString("leader_id"));
        int storageSlots = rs.getInt("storage_slots");
        double maxHealthBonus = rs.getDouble("max_health_bonus");
        List<UUID> members = getMembers(id);
        return new Team(id, name, leaderId, members, storageSlots, maxHealthBonus);
    }
}
