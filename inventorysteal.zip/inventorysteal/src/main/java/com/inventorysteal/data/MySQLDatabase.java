package com.inventorysteal.data;

import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;

/**
 * MySQL implementation of {@link Database}.
 *
 * <p>Uses HikariCP for connection pooling. All calls must be made from
 * a context that is safe to block (main thread or dedicated async thread).
 * The HikariCP library is shaded into the plugin JAR.
 */
public class MySQLDatabase implements Database {

    private static final Logger LOGGER = Logger.getLogger(MySQLDatabase.class.getName());

    private final String host;
    private final int port;
    private final String database;
    private final String username;
    private final String password;
    private final int poolSize;
    private final long connectionTimeout;
    private final long idleTimeout;
    private final long maxLifetime;

    private HikariDataSource dataSource;

    /**
     * Construct a MySQL database connector.
     *
     * @param host              hostname or IP
     * @param port              MySQL port (default 3306)
     * @param database          database/schema name
     * @param username          MySQL user
     * @param password          MySQL password
     * @param poolSize          maximum pool size
     * @param connectionTimeout ms to wait for a connection
     * @param idleTimeout       ms an idle connection is kept open
     * @param maxLifetime       ms before a connection is recycled
     */
    public MySQLDatabase(String host, int port, String database,
                         String username, String password,
                         int poolSize, long connectionTimeout,
                         long idleTimeout, long maxLifetime) {
        this.host = host;
        this.port = port;
        this.database = database;
        this.username = username;
        this.password = password;
        this.poolSize = poolSize;
        this.connectionTimeout = connectionTimeout;
        this.idleTimeout = idleTimeout;
        this.maxLifetime = maxLifetime;
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void initialize() throws Exception {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + database
                          + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(poolSize);
        config.setConnectionTimeout(connectionTimeout);
        config.setIdleTimeout(idleTimeout);
        config.setMaxLifetime(maxLifetime);
        config.setPoolName("InventorySteal-MySQL");
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        dataSource = new HikariDataSource(config);
        createTables();
        LOGGER.info("MySQL database connected to " + host + ":" + port + "/" + database);
    }

    @Override
    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    private Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // -------------------------------------------------------------------------
    // Schema
    // -------------------------------------------------------------------------

    private void createTables() throws SQLException {
        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS teams (" +
                "  id VARCHAR(36) PRIMARY KEY," +
                "  name VARCHAR(32) NOT NULL," +
                "  leader_id VARCHAR(36) NOT NULL," +
                "  storage_slots INT NOT NULL DEFAULT 27," +
                "  max_health_bonus DOUBLE NOT NULL DEFAULT 0.0," +
                "  UNIQUE KEY uq_team_name (name)" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_members (" +
                "  team_id VARCHAR(36) NOT NULL," +
                "  player_uuid VARCHAR(36) NOT NULL," +
                "  joined_at VARCHAR(50) NOT NULL," +
                "  PRIMARY KEY (team_id, player_uuid)," +
                "  INDEX idx_player (player_uuid)," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_invites (" +
                "  team_id VARCHAR(36) NOT NULL," +
                "  invited_player VARCHAR(36) NOT NULL," +
                "  invited_by VARCHAR(36) NOT NULL," +
                "  expires_at VARCHAR(50) NOT NULL," +
                "  PRIMARY KEY (team_id, invited_player)," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS team_inventories (" +
                "  team_id VARCHAR(36) PRIMARY KEY," +
                "  player_inventory MEDIUMTEXT," +
                "  ender_chest MEDIUMTEXT," +
                "  team_storage MEDIUMTEXT," +
                "  FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
            );
        }
    }

    // -------------------------------------------------------------------------
    // Team CRUD
    // -------------------------------------------------------------------------

    @Override
    public void createTeam(Team team) {
        String sql = "INSERT INTO teams(id, name, leader_id, storage_slots, max_health_bonus) " +
                     "VALUES (?, ?, ?, ?, ?);";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, team.getId().toString());
            ps.setString(2, team.getName());
            ps.setString(3, team.getLeaderId().toString());
            ps.setInt(4, team.getStorageSlots());
            ps.setDouble(5, team.getMaxHealthBonus());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to create team " + team.getName() + ": " + e.getMessage());
        }
    }

    @Override
    public Team getTeam(UUID teamId) {
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus " +
                     "FROM teams WHERE id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team " + teamId + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public Team getTeamByName(String name) {
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus " +
                     "FROM teams WHERE name = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team by name " + name + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public Team getTeamByMember(UUID playerUUID) {
        String sql = "SELECT t.id, t.name, t.leader_id, t.storage_slots, t.max_health_bonus " +
                     "FROM teams t INNER JOIN team_members m ON t.id = m.team_id " +
                     "WHERE m.player_uuid = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, playerUUID.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildTeam(rs);
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team for member " + playerUUID + ": " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Team> getAllTeams() {
        List<Team> teams = new ArrayList<>();
        String sql = "SELECT id, name, leader_id, storage_slots, max_health_bonus FROM teams;";
        try (Connection conn = getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) teams.add(buildTeam(rs));
        } catch (SQLException e) {
            LOGGER.severe("Failed to load all teams: " + e.getMessage());
        }
        return teams;
    }

    @Override
    public void updateTeam(Team team) {
        String sql = "UPDATE teams SET name = ?, leader_id = ?, storage_slots = ?, " +
                     "max_health_bonus = ? WHERE id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, team.getName());
            ps.setString(2, team.getLeaderId().toString());
            ps.setInt(3, team.getStorageSlots());
            ps.setDouble(4, team.getMaxHealthBonus());
            ps.setString(5, team.getId().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to update team " + team.getName() + ": " + e.getMessage());
        }
    }

    @Override
    public void deleteTeam(UUID teamId) {
        String sql = "DELETE FROM teams WHERE id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to delete team " + teamId + ": " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Member management
    // -------------------------------------------------------------------------

    @Override
    public void addMember(UUID teamId, UUID playerUUID) {
        String sql = "INSERT IGNORE INTO team_members(team_id, player_uuid, joined_at) " +
                     "VALUES (?, ?, ?);";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerUUID.toString());
            ps.setString(3, Instant.now().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to add member: " + e.getMessage());
        }
    }

    @Override
    public void removeMember(UUID teamId, UUID playerUUID) {
        String sql = "DELETE FROM team_members WHERE team_id = ? AND player_uuid = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerUUID.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to remove member: " + e.getMessage());
        }
    }

    @Override
    public List<UUID> getMembers(UUID teamId) {
        List<UUID> members = new ArrayList<>();
        String sql = "SELECT player_uuid FROM team_members WHERE team_id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) members.add(UUID.fromString(rs.getString("player_uuid")));
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load members: " + e.getMessage());
        }
        return members;
    }

    // -------------------------------------------------------------------------
    // Invite management
    // -------------------------------------------------------------------------

    @Override
    public void addInvite(PendingInvite invite) {
        String sql = "INSERT INTO team_invites(team_id, invited_player, invited_by, expires_at) " +
                     "VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE invited_by = VALUES(invited_by), " +
                     "expires_at = VALUES(expires_at);";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, invite.getTeamId().toString());
            ps.setString(2, invite.getInvitedPlayer().toString());
            ps.setString(3, invite.getInvitedBy().toString());
            ps.setString(4, invite.getExpiresAt().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to add invite: " + e.getMessage());
        }
    }

    @Override
    public void removeInvite(UUID teamId, UUID invitedPlayer) {
        String sql = "DELETE FROM team_invites WHERE team_id = ? AND invited_player = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, invitedPlayer.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to remove invite: " + e.getMessage());
        }
    }

    @Override
    public Map<UUID, PendingInvite> getInvites(UUID teamId) {
        Map<UUID, PendingInvite> invites = new HashMap<>();
        String sql = "SELECT team_id, invited_player, invited_by, expires_at " +
                     "FROM team_invites WHERE team_id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    UUID invitedPlayer = UUID.fromString(rs.getString("invited_player"));
                    UUID invitedBy = UUID.fromString(rs.getString("invited_by"));
                    Instant expiresAt = Instant.parse(rs.getString("expires_at"));
                    PendingInvite invite = new PendingInvite(teamId, invitedPlayer, invitedBy, expiresAt);
                    invites.put(invitedPlayer, invite);
                }
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load invites: " + e.getMessage());
        }
        return invites;
    }

    // -------------------------------------------------------------------------
    // Inventory storage
    // -------------------------------------------------------------------------

    @Override
    public void saveTeamInventory(UUID teamId, String playerInventory,
                                  String enderChestData, String teamStorageData) {
        String sql = "INSERT INTO team_inventories(team_id, player_inventory, ender_chest, team_storage) " +
                     "VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE player_inventory = VALUES(player_inventory), " +
                     "ender_chest = VALUES(ender_chest), team_storage = VALUES(team_storage);";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            ps.setString(2, playerInventory);
            ps.setString(3, enderChestData);
            ps.setString(4, teamStorageData);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save team inventory: " + e.getMessage());
        }
    }

    @Override
    public String[] getTeamInventory(UUID teamId) {
        String sql = "SELECT player_inventory, ender_chest, team_storage " +
                     "FROM team_inventories WHERE team_id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, teamId.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new String[]{
                        rs.getString("player_inventory"),
                        rs.getString("ender_chest"),
                        rs.getString("team_storage")
                    };
                }
            }
        } catch (SQLException e) {
            LOGGER.severe("Failed to load team inventory: " + e.getMessage());
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Upgrades
    // -------------------------------------------------------------------------

    @Override
    public void saveStorageSize(UUID teamId, int slots) {
        String sql = "UPDATE teams SET storage_slots = ? WHERE id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, slots);
            ps.setString(2, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save storage size: " + e.getMessage());
        }
    }

    @Override
    public void saveMaxHealthBonus(UUID teamId, double bonus) {
        String sql = "UPDATE teams SET max_health_bonus = ? WHERE id = ?;";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, bonus);
            ps.setString(2, teamId.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOGGER.severe("Failed to save health bonus: " + e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private Team buildTeam(ResultSet rs) throws SQLException {
        UUID id = UUID.fromString(rs.getString("id"));
        String name = rs.getString("name");
        UUID leaderId = UUID.fromString(rs.getString("leader_id"));
        int storageSlots = rs.getInt("storage_slots");
        double maxHealthBonus = rs.getDouble("max_health_bonus");
        List<UUID> members = getMembers(id);
        return new Team(id, name, leaderId, members, storageSlots, maxHealthBonus);
    }
}
