package com.inventorysteal;

import com.inventorysteal.command.InventoryStealCommand;
import com.inventorysteal.command.TeamAdminCommand;
import com.inventorysteal.command.TeamCommand;
import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.data.Database;
import com.inventorysteal.data.MySQLDatabase;
import com.inventorysteal.data.SQLiteDatabase;
import com.inventorysteal.listener.DeathListener;
import com.inventorysteal.listener.InventoryListener;
import com.inventorysteal.listener.PlayerListener;
import com.inventorysteal.listener.PotionListener;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.recipe.HeartRecipe;
import com.inventorysteal.repository.InventoryRepository;
import com.inventorysteal.repository.TeamRepository;
import com.inventorysteal.service.DeathService;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.service.InventorySyncService;
import com.inventorysteal.service.TeamService;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Objects;
import java.util.logging.Level;

/**
 * Main entry point for the InventorySteal plugin.
 */
public final class InventoryStealPlugin extends JavaPlugin {

    // -------------------------------------------------------------------------
    // Fields
    // -------------------------------------------------------------------------

    private ConfigManager configManager;
    private MessagesManager messagesManager;
    private Database database;
    private TeamManager teamManager;
    private SharedInventoryManager sharedInvManager;
    private InventorySyncService inventorySyncService;
    private HealthSyncService healthSyncService;
    private DeathService deathService;
    private TeamService teamService;
    private HeartRecipe heartRecipe;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void onEnable() {
        getLogger().info("╔══════════════════════════════════╗");
        getLogger().info("║     InventorySteal v" + getDescription().getVersion() + "        ║");
        getLogger().info("║  Team-based shared inventory      ║");
        getLogger().info("╚══════════════════════════════════╝");

        // 1. Save bundled defaults if absent
        saveDefaultConfig();

        // =======================================================
        // 🔒 LICENSE VERIFICATION SYSTEM
        // =======================================================
        String licenseKey = getConfig().getString("license-key");
        String apiUrl = "https://licance.allayempires.in/api/v1/verify"; 

        if (!LicenseValidator.verify(this, apiUrl, "inventorysteal", licenseKey)) {
            getLogger().severe("Invalid License! Disabling plugin...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        // =======================================================

        // 2. Config + Messages
        configManager = new ConfigManager(this);
        messagesManager = new MessagesManager(this);

        // 3. Database
        if (!initDatabase()) {
            getLogger().severe("Failed to initialise database. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // 4. Repositories
        TeamRepository teamRepository = new TeamRepository(database);
        InventoryRepository inventoryRepository = new InventoryRepository(database);

        // 5. Managers
        sharedInvManager = new SharedInventoryManager();
        teamManager = new TeamManager(teamRepository, inventoryRepository, configManager);

        // 6. Services
        inventorySyncService = new InventorySyncService(teamManager, sharedInvManager, configManager, this);
        healthSyncService = new HealthSyncService(teamManager, sharedInvManager, configManager, this);
        deathService = new DeathService(teamManager, sharedInvManager, configManager, messagesManager, this);
        teamService = new TeamService(
            teamManager, inventorySyncService, healthSyncService,
            configManager, messagesManager, this
        );

        // 7. Heart recipe
        heartRecipe = new HeartRecipe(this, teamManager, healthSyncService, configManager, messagesManager);
        if (configManager.isHeartRecipeEnabled()) {
            heartRecipe.register();
        }

        // 8. Register event listeners
        registerListeners();

        // 9. Register commands
        registerCommands();

        // 10. Load all teams from DB into memory
        teamManager.loadAll();

        getLogger().info("InventorySteal enabled successfully.");
    }

    @Override
    public void onDisable() {
        if (teamManager != null) {
            for (var team : teamManager.getAllTeams()) {
                teamManager.saveInventories(team);
            }
            getLogger().info("Saved all team inventories.");
        }

        if (heartRecipe != null && configManager != null && configManager.isHeartRecipeEnabled()) {
            heartRecipe.unregister();
        }

        if (database != null) {
            database.close();
            getLogger().info("Database connection closed.");
        }

        getLogger().info("InventorySteal disabled.");
    }

    // -------------------------------------------------------------------------
    // Initialisation helpers
    // -------------------------------------------------------------------------

    private boolean initDatabase() {
        String type = configManager.getDbType();
        if ("mysql".equalsIgnoreCase(type)) {
            database = new MySQLDatabase(
                configManager.getMysqlHost(),
                configManager.getMysqlPort(),
                configManager.getMysqlDatabase(),
                configManager.getMysqlUsername(),
                configManager.getMysqlPassword(),
                configManager.getMysqlPoolSize(),
                configManager.getMysqlConnectionTimeout(),
                configManager.getMysqlIdleTimeout(),
                configManager.getMysqlMaxLifetime()
            );
        } else {
            File dbFile = new File(getDataFolder(), configManager.getSqliteFile());
            database = new SQLiteDatabase(dbFile);
        }

        try {
            database.initialize();
            getLogger().info("Database initialised (" + type.toUpperCase() + ").");
            return true;
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Database initialisation failed: " + e.getMessage(), e);
            return false;
        }
    }

    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();

        pm.registerEvents(new InventoryListener(
            teamManager, sharedInvManager, inventorySyncService, this), this);

        pm.registerEvents(new PlayerListener(
            teamManager, sharedInvManager, inventorySyncService, healthSyncService, configManager, this), this);

        pm.registerEvents(new DeathListener(
            teamManager, sharedInvManager, deathService, inventorySyncService, this), this);

        pm.registerEvents(new PotionListener(
            teamManager, sharedInvManager, configManager, this), this);

        pm.registerEvents(heartRecipe, this);

        getLogger().info("Listeners registered.");
    }

    private void registerCommands() {
        TeamCommand teamCmd = new TeamCommand(
            teamManager, sharedInvManager, teamService,
            inventorySyncService, healthSyncService, messagesManager);

        TeamAdminCommand teamAdminCmd = new TeamAdminCommand(
            teamManager, sharedInvManager, healthSyncService, inventorySyncService, messagesManager);

        InventoryStealCommand isCmd = new InventoryStealCommand(this, messagesManager);

        Objects.requireNonNull(getCommand("team")).setExecutor(teamCmd);
        Objects.requireNonNull(getCommand("team")).setTabCompleter(teamCmd);
        Objects.requireNonNull(getCommand("teamadmin")).setExecutor(teamAdminCmd);
        Objects.requireNonNull(getCommand("teamadmin")).setTabCompleter(teamAdminCmd);
        Objects.requireNonNull(getCommand("inventorysteal")).setExecutor(isCmd);
        Objects.requireNonNull(getCommand("inventorysteal")).setTabCompleter(isCmd);

        getLogger().info("Commands registered.");
    }

    public ConfigManager getConfigManager() { return configManager; }
    public MessagesManager getMessagesManager() { return messagesManager; }
    public HeartRecipe getHeartRecipe() { return heartRecipe; }
    public TeamManager getTeamManager() { return teamManager; }
    public HealthSyncService getHealthSyncService() { return healthSyncService; }
}
