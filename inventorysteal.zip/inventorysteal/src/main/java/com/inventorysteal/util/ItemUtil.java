package com.inventorysteal.util;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

/**
 * General-purpose item manipulation utilities.
 */
public final class ItemUtil {

    private ItemUtil() {
        throw new UnsupportedOperationException("Utility class");
    }

    // -------------------------------------------------------------------------
    // Item creation helpers
    // -------------------------------------------------------------------------

    /**
     * Build a simple {@link ItemStack} with a display name and lore, applying
     * Bukkit color-code translations (using {@code &} as the code character).
     *
     * @param material  item material
     * @param name      display name ({@code &} color codes supported)
     * @param lore      lore lines ({@code &} color codes supported), may be empty
     * @return          the constructed {@link ItemStack}
     */
    public static ItemStack buildItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(colorize(name));
            if (!lore.isEmpty()) {
                meta.setLore(lore.stream().map(ItemUtil::colorize).toList());
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    /**
     * Build an item with custom model data (for resource-pack override).
     *
     * @param material        item material
     * @param name            display name
     * @param lore            lore lines
     * @param customModelData custom model data value (0 = no override)
     * @return the constructed {@link ItemStack}
     */
    public static ItemStack buildItemWithModel(Material material, String name,
                                               List<String> lore, int customModelData) {
        ItemStack item = buildItem(material, name, lore);
        if (customModelData > 0) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setCustomModelData(customModelData);
                item.setItemMeta(meta);
            }
        }
        return item;
    }

    // -------------------------------------------------------------------------
    // Comparison helpers
    // -------------------------------------------------------------------------

    /**
     * Check whether two item stacks are "type-equal" — same material, same
     * display name and same custom model data, ignoring stack size and damage.
     *
     * @param a first item (may be {@code null})
     * @param b second item (may be {@code null})
     * @return {@code true} if both items represent the same type
     */
    public static boolean isSameType(ItemStack a, ItemStack b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        if (a.getType() != b.getType()) return false;
        ItemMeta metaA = a.getItemMeta();
        ItemMeta metaB = b.getItemMeta();
        if (metaA == null && metaB == null) return true;
        if (metaA == null || metaB == null) return false;
        if (!java.util.Objects.equals(metaA.getDisplayName(), metaB.getDisplayName())) return false;
        return metaA.getCustomModelData() == metaB.getCustomModelData();
    }

    /**
     * Check whether a player's inventory contains at least one item matching
     * the type of the given stack.
     *
     * @param contents inventory contents
     * @param template the item type to look for
     * @return {@code true} if at least one match is found
     */
    public static boolean containsType(ItemStack[] contents, ItemStack template) {
        for (ItemStack item : contents) {
            if (isSameType(item, template)) return true;
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Color helper
    // -------------------------------------------------------------------------

    /**
     * Translate {@code &} color codes to the Bukkit § format.
     *
     * @param text raw string with {@code &} codes
     * @return translated string
     */
    public static String colorize(String text) {
        if (text == null) return "";
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', text);
    }

    /**
     * Translate a list of strings.
     *
     * @param lines raw lines
     * @return list with {@code &} codes translated
     */
    public static List<String> colorize(List<String> lines) {
        return lines.stream().map(ItemUtil::colorize).toList();
    }

    // -------------------------------------------------------------------------
    // Array helpers
    // -------------------------------------------------------------------------

    /**
     * Count non-null items in an array.
     *
     * @param items item array
     * @return number of non-null slots
     */
    public static int countItems(ItemStack[] items) {
        if (items == null) return 0;
        int count = 0;
        for (ItemStack item : items) {
            if (item != null && item.getType() != Material.AIR) count++;
        }
        return count;
    }

    /**
     * Return a human-readable string describing array contents for debug logging.
     *
     * @param items item array
     * @return debug string
     */
    public static String debugArray(ItemStack[] items) {
        if (items == null) return "null";
        return "ItemStack[" + items.length + "]{" + countItems(items) + " non-null}";
    }
}
