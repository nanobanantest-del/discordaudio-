package com.inventorysteal.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.logging.Logger;

/**
 * Utility class for serialising and deserialising {@link ItemStack} arrays to
 * and from Base64-encoded strings suitable for database storage.
 *
 * <p>Uses Bukkit's own object-stream wrappers so that all item NBT data is
 * preserved across server restarts without depending on any NMS internals.
 */
public final class SerializationUtil {

    private static final Logger LOGGER = Logger.getLogger(SerializationUtil.class.getName());

    private SerializationUtil() {
        throw new UnsupportedOperationException("Utility class");
    }

    // -------------------------------------------------------------------------
    // ItemStack[] serialisation
    // -------------------------------------------------------------------------

    /**
     * Serialise an array of {@link ItemStack}s to a Base64-encoded string.
     * {@code null} slots are preserved so that slot positions are maintained
     * on deserialisation.
     *
     * @param items the array to serialise (may contain {@code null} entries)
     * @return Base64 string, or {@code null} if the input is {@code null}
     * @throws IllegalStateException if serialisation fails
     */
    public static String serializeItemArray(ItemStack[] items) {
        if (items == null) return null;
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             BukkitObjectOutputStream boos = new BukkitObjectOutputStream(baos)) {

            boos.writeInt(items.length);
            for (ItemStack item : items) {
                boos.writeObject(item); // writes null as a null marker
            }
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        } catch (IOException e) {
            LOGGER.severe("Failed to serialise ItemStack array: " + e.getMessage());
            throw new IllegalStateException("ItemStack serialisation failed", e);
        }
    }

    /**
     * Deserialise a Base64-encoded string back into an {@link ItemStack} array.
     *
     * @param data Base64 string produced by {@link #serializeItemArray}
     * @return reconstructed array, or {@code null} if {@code data} is {@code null}
     * @throws IllegalStateException if deserialisation fails
     */
    public static ItemStack[] deserializeItemArray(String data) {
        if (data == null || data.isEmpty()) return null;
        try (ByteArrayInputStream bais = new ByteArrayInputStream(Base64.getDecoder().decode(data));
             BukkitObjectInputStream bois = new BukkitObjectInputStream(bais)) {

            int length = bois.readInt();
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) {
                items[i] = (ItemStack) bois.readObject();
            }
            return items;
        } catch (IOException | ClassNotFoundException e) {
            LOGGER.severe("Failed to deserialise ItemStack array: " + e.getMessage());
            throw new IllegalStateException("ItemStack deserialisation failed", e);
        }
    }

    // -------------------------------------------------------------------------
    // Null-safe helpers
    // -------------------------------------------------------------------------

    /**
     * Produce a zeroed (all-null) array of the given length.
     * Convenience factory so callers don't need to think about array sizes.
     *
     * @param size desired array length
     * @return new {@code ItemStack[size]} with all {@code null} entries
     */
    public static ItemStack[] emptyArray(int size) {
        return new ItemStack[size];
    }

    /**
     * Deep-clone an {@link ItemStack} array.  Null slots are preserved.
     *
     * @param source original array
     * @return independent copy, or {@code null} if source is {@code null}
     */
    public static ItemStack[] cloneArray(ItemStack[] source) {
        if (source == null) return null;
        ItemStack[] copy = new ItemStack[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = (source[i] == null) ? null : source[i].clone();
        }
        return copy;
    }
}
