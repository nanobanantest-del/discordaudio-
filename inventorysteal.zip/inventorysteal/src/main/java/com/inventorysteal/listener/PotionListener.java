package com.inventorysteal.listener;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;

import java.util.UUID;

/**
 * Synchronises potion effect changes (apply and remove) between teammates.
 *
 * <p>When one player gains a potion effect, all online teammates receive the
 * same effect with the same duration and amplifier.
 * When one player's effects are cleared (e.g. drinking milk), all teammates
 * also lose all their effects.
 */
public class PotionListener implements Listener {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final ConfigManager config;
    private final JavaPlugin plugin;

    public PotionListener(TeamManager teamManager,
                          SharedInventoryManager sharedInvManager,
                          ConfigManager config,
                          JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.config = config;
        this.plugin = plugin;
    }

    /**
     * Mirror potion-effect changes to all online teammates.
     *
     * <p>We use {@link EventPriority#MONITOR} so cancelled events (blocked by
     * another plugin) are not propagated.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityPotionEffect(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null || team.getMembers().size() <= 1) return;

        EntityPotionEffectEvent.Action action = event.getAction();

        switch (action) {
            case ADDED, CHANGED -> {
                PotionEffect newEffect = event.getNewEffect();
                if (newEffect == null) return;
                propagateEffectAdded(player, team, newEffect);
            }
            case REMOVED, CLEARED -> {
                PotionEffect oldEffect = event.getOldEffect();
                if (action == EntityPotionEffectEvent.Action.CLEARED || oldEffect == null) {
                    // All effects cleared (e.g. milk) — remove all from teammates
                    propagateEffectsCleared(player, team);
                } else {
                    propagateEffectRemoved(player, team, oldEffect);
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void propagateEffectAdded(Player source, Team team, PotionEffect effect) {
        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;

            sharedInvManager.beginSync(teammate.getUniqueId());
            try {
                teammate.addPotionEffect(effect);
            } finally {
                sharedInvManager.endSync(teammate.getUniqueId());
            }
        }
    }

    private void propagateEffectRemoved(Player source, Team team, PotionEffect effect) {
        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;

            sharedInvManager.beginSync(teammate.getUniqueId());
            try {
                teammate.removePotionEffect(effect.getType());
            } finally {
                sharedInvManager.endSync(teammate.getUniqueId());
            }
        }
    }

    private void propagateEffectsCleared(Player source, Team team) {
        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;

            sharedInvManager.beginSync(teammate.getUniqueId());
            try {
                // Remove all active effects
                teammate.getActivePotionEffects().forEach(e ->
                    teammate.removePotionEffect(e.getType()));
            } finally {
                sharedInvManager.endSync(teammate.getUniqueId());
            }
        }
    }
}
