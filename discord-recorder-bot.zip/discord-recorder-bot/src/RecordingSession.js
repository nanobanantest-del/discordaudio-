'use strict';

/**
 * RecordingSession.js
 * Manages the lifecycle of a single guild recording:
 *   - Subscribes to each speaker's audio stream via @discordjs/voice
 *   - Pipes raw Opus → PCM via prism-media
 *   - Applies noise suppression (RNNoise wrapper or FFmpeg fallback)
 *   - Detects silence / auto-stop
 *   - Normalises per-user volume
 *   - Exports clean_<userId>.mp3 + final_mix.mp3
 *   - DMs results to the command invoker
 */

const EventEmitter = require('events');
const path  = require('path');
const fs    = require('fs');
const os    = require('os');
const { EndBehaviorType } = require('@discordjs/voice');
const prism = require('prism-media');

const AudioPipeline  = require('./AudioPipeline');
const MixAndExport   = require('./MixAndExport');
const { log }        = require('./logger');

// ─── Config (overrideable via .env) ─────────────────────────────────────────
const SILENCE_THRESHOLD_MS  = parseInt(process.env.SILENCE_THRESHOLD_MS  ?? '30000', 10); // auto-stop after 30s silence
const MAX_RECORDING_MS      = parseInt(process.env.MAX_RECORDING_MS      ?? '3600000', 10); // hard cap 1 hour
const SAMPLE_RATE           = 48_000;
const CHANNELS              = 2;     // stereo
const BYTES_PER_SAMPLE      = 2;     // 16-bit PCM

class RecordingSession extends EventEmitter {
  /**
   * @param {string} guildId
   * @param {import('@discordjs/voice').VoiceConnection} connection
   * @param {import('discord.js').ChatInputCommandInteraction} interaction
   */
  constructor(guildId, connection, interaction) {
    super();
    this.guildId     = guildId;
    this.connection  = connection;
    this.interaction = interaction;
    this.invoker     = interaction.user;

    /** @type {Map<string, AudioPipeline>} userId → pipeline */
    this.pipelines   = new Map();

    /** Timestamp map for diarization: userId → [{start, end}] */
    this.speakEvents = new Map();

    this.startTime   = null;
    this.outputDir   = null;
    this._stopped    = false;

    // Timers
    this._silenceTimer  = null;
    this._maxTimer      = null;
  }

  // ─── Public ─────────────────────────────────────────────────────────────────

  async start() {
    this.startTime = Date.now();
    this.outputDir = fs.mkdtempSync(path.join(os.tmpdir(), `drec-${this.guildId}-`));
    log('info', `[${this.guildId}] Session started → ${this.outputDir}`);

    this._startMaxTimer();
    this._resetSilenceTimer(); // begin silence countdown immediately

    const receiver = this.connection.receiver;

    // Subscribe to anyone who speaks
    receiver.speaking.on('start', (userId) => {
      if (this._stopped) return;
      this._clearSilenceTimer();  // user is speaking → reset silence window

      if (!this.pipelines.has(userId)) {
        this._subscribeSpeaker(userId, receiver);
      }

      // Diarization: record start timestamp
      if (!this.speakEvents.has(userId)) this.speakEvents.set(userId, []);
      const events = this.speakEvents.get(userId);
      // Only open a new event if last one is closed
      const last = events[events.length - 1];
      if (!last || last.end !== null) {
        events.push({ start: Date.now() - this.startTime, end: null });
      }
    });

    receiver.speaking.on('end', (userId) => {
      if (this._stopped) return;
      this._resetSilenceTimer();

      // Close speak event
      const events = this.speakEvents.get(userId);
      if (events?.length) {
        const last = events[events.length - 1];
        if (last && last.end === null) last.end = Date.now() - this.startTime;
      }
    });
  }

  async stop() {
    if (this._stopped) return;
    this._stopped = true;

    this._clearSilenceTimer();
    clearTimeout(this._maxTimer);

    log('info', `[${this.guildId}] Stopping session — finalising ${this.pipelines.size} user pipeline(s)`);

    // Close all pipelines (flushes remaining PCM to disk)
    const flushPromises = [];
    for (const [userId, pipeline] of this.pipelines) {
      flushPromises.push(pipeline.flush().catch(e => log('warn', `Flush error for ${userId}: ${e.message}`)));
    }
    await Promise.all(flushPromises);

    // Process & export
    try {
      await this._processAndDeliver();
    } catch (err) {
      log('error', `[${this.guildId}] Processing error: ${err.message}`);
      await this._dmUser(`❌ An error occurred during audio processing: ${err.message}`).catch(() => {});
    }

    this.emit('ended');
  }

  // ─── Private ─────────────────────────────────────────────────────────────────

  _subscribeSpeaker(userId, receiver) {
    log('info', `[${this.guildId}] Subscribing to speaker: ${userId}`);

    const opusStream = receiver.subscribe(userId, {
      end: { behavior: EndBehaviorType.AfterSilence, duration: 500 },
    });

    const pcmPath = path.join(this.outputDir, `raw_${userId}.pcm`);
    const pipeline = new AudioPipeline(userId, opusStream, pcmPath, {
      sampleRate : SAMPLE_RATE,
      channels   : CHANNELS,
    });

    this.pipelines.set(userId, pipeline);
    pipeline.start();

    // Cleanup when the subscription ends naturally (user left / disconnected)
    opusStream.on('end', () => {
      log('info', `[${this.guildId}] Opus stream ended for ${userId}`);
    });
  }

  _resetSilenceTimer() {
    this._clearSilenceTimer();
    this._silenceTimer = setTimeout(() => {
      log('info', `[${this.guildId}] Auto-stopping after ${SILENCE_THRESHOLD_MS / 1000}s of silence`);
      this.stop();
    }, SILENCE_THRESHOLD_MS);
  }

  _clearSilenceTimer() {
    if (this._silenceTimer) {
      clearTimeout(this._silenceTimer);
      this._silenceTimer = null;
    }
  }

  _startMaxTimer() {
    this._maxTimer = setTimeout(() => {
      log('info', `[${this.guildId}] Hit max recording duration (${MAX_RECORDING_MS / 60000} min). Stopping.`);
      this.stop();
    }, MAX_RECORDING_MS);
  }

  async _processAndDeliver() {
    const mixer = new MixAndExport(this.outputDir, this.pipelines, this.speakEvents, {
      sampleRate : SAMPLE_RATE,
      channels   : CHANNELS,
      bytesPerSample: BYTES_PER_SAMPLE,
      startTime  : this.startTime,
    });

    const results = await mixer.run();

    // DM the invoker with all files
    await this._dmUser(
      `🎙️ **Recording complete!**\n` +
      `⏱️ Duration: ${Math.round((Date.now() - this.startTime) / 1000)}s\n` +
      `👥 Speakers captured: ${results.users.length}\n` +
      `📎 Attached: per-user MP3s + final mix\n\n` +
      `📝 **Speaker timestamps:**\n${this._formatDiarization()}`
    , results.attachments);

    // Cleanup temp dir after delivery
    this._cleanup();
  }

  _formatDiarization() {
    let out = '';
    for (const [userId, events] of this.speakEvents) {
      const segs = events.map(e => {
        const s = _msToTimestamp(e.start);
        const en = e.end != null ? _msToTimestamp(e.end) : 'ongoing';
        return `${s}–${en}`;
      }).join(', ');
      out += `• <@${userId}>: ${segs}\n`;
    }
    return out || '_No speech detected._';
  }

  async _dmUser(content, attachments = []) {
    try {
      const dm = await this.invoker.createDM();
      // Discord DM can have max 10 attachments & 25 MB per message
      // Split if needed
      if (attachments.length === 0) {
        await dm.send({ content });
        return;
      }

      // Send text first, then files in batches of 10
      await dm.send({ content });
      for (let i = 0; i < attachments.length; i += 10) {
        const batch = attachments.slice(i, i + 10);
        await dm.send({ files: batch });
      }
    } catch (err) {
      log('error', `DM failed: ${err.message}`);
    }
  }

  _cleanup() {
    try {
      fs.rmSync(this.outputDir, { recursive: true, force: true });
      log('info', `[${this.guildId}] Temp dir cleaned up`);
    } catch (e) {
      log('warn', `Cleanup failed: ${e.message}`);
    }
  }
}

function _msToTimestamp(ms) {
  const totalSec = Math.floor(ms / 1000);
  const m = Math.floor(totalSec / 60).toString().padStart(2, '0');
  const s = (totalSec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

module.exports = RecordingSession;
