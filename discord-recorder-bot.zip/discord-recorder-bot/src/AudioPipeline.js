'use strict';

/**
 * AudioPipeline.js
 * Per-user audio pipeline:
 *   Opus stream → prism-media decoder → PCM → (RNNoise | FFmpeg NR) → disk
 *
 * RNNoise is preferred when the native addon is available.
 * Falls back to FFmpeg's `arnndn` / `anlmdn` filter automatically.
 */

const fs      = require('fs');
const path    = require('path');
const { Transform, pipeline } = require('stream');
const prism   = require('prism-media');
const { log } = require('./logger');

// Try to load RNNoise native addon (optional)
let rnnoise = null;
try {
  rnnoise = require('rnnoise');  // optional: npm install rnnoise
  log('info', 'RNNoise native addon loaded ✓');
} catch (_) {
  log('info', 'RNNoise native addon not found — will use FFmpeg NR fallback');
}

class AudioPipeline {
  /**
   * @param {string} userId
   * @param {import('stream').Readable} opusStream
   * @param {string} pcmOutputPath
   * @param {{ sampleRate: number, channels: number }} opts
   */
  constructor(userId, opusStream, pcmOutputPath, opts = {}) {
    this.userId       = userId;
    this.opusStream   = opusStream;
    this.pcmOutputPath = pcmOutputPath;
    this.sampleRate   = opts.sampleRate ?? 48_000;
    this.channels     = opts.channels   ?? 2;
    this._writeStream = null;
    this._pipelineDestroyed = false;
    this._bytesWritten = 0;
  }

  start() {
    // Opus → raw 16-bit signed LE PCM at 48 kHz stereo
    const decoder = new prism.opus.Decoder({
      rate      : this.sampleRate,
      channels  : this.channels,
      frameSize : 960,  // 20ms frame @ 48 kHz
    });

    this._writeStream = fs.createWriteStream(this.pcmOutputPath);

    const chunks = [];
    // Buffer PCM in memory for RNNoise processing (frame-by-frame)
    let buffer = Buffer.alloc(0);

    // RNNoise processes 480-sample (960-byte mono / 1920-byte stereo) frames
    const FRAME_SAMPLES  = 480;
    const FRAME_BYTES    = FRAME_SAMPLES * this.channels * 2; // 16-bit = 2 bytes/sample

    const self = this;

    const noiseFilter = rnnoise
      ? new Transform({
          transform(chunk, _enc, cb) {
            buffer = Buffer.concat([buffer, chunk]);
            while (buffer.length >= FRAME_BYTES) {
              const frame  = buffer.subarray(0, FRAME_BYTES);
              buffer       = buffer.subarray(FRAME_BYTES);
              const cleaned = _applyRNNoise(frame, self.channels);
              self._bytesWritten += cleaned.length;
              this.push(cleaned);
            }
            cb();
          },
          flush(cb) {
            if (buffer.length > 0) {
              // Pad last frame with silence and process
              const padded = Buffer.concat([buffer, Buffer.alloc(FRAME_BYTES - buffer.length)]);
              const cleaned = _applyRNNoise(padded, self.channels);
              self._bytesWritten += cleaned.length;
              this.push(cleaned);
            }
            cb();
          },
        })
      : new Transform({
          // Pass-through: FFmpeg NR is applied later at export time
          transform(chunk, _enc, cb) {
            self._bytesWritten += chunk.length;
            cb(null, chunk);
          },
        });

    // Build stream pipeline
    this.opusStream
      .pipe(decoder)
      .pipe(noiseFilter)
      .pipe(this._writeStream);

    this.opusStream.on('error', (e) => log('warn', `[${this.userId}] Opus stream error: ${e.message}`));
    decoder.on('error',        (e) => log('warn', `[${this.userId}] Decoder error: ${e.message}`));
    noiseFilter.on('error',    (e) => log('warn', `[${this.userId}] Noise filter error: ${e.message}`));
    this._writeStream.on('error', (e) => log('warn', `[${this.userId}] Write error: ${e.message}`));
  }

  /** Gracefully flush and close the write stream */
  flush() {
    return new Promise((resolve) => {
      if (!this._writeStream || this._writeStream.closed) return resolve();
      this._writeStream.end(() => resolve());
    });
  }

  get hasAudio() {
    return this._bytesWritten > 0;
  }

  get pcmPath() {
    return this.pcmOutputPath;
  }
}

// ─── RNNoise helper ──────────────────────────────────────────────────────────

/**
 * Apply RNNoise to a single PCM frame (interleaved stereo or mono).
 * RNNoise works on mono Float32 frames; we split stereo, process each channel.
 * @param {Buffer} frame  - 16-bit signed LE PCM
 * @param {number} channels
 * @returns {Buffer}
 */
function _applyRNNoise(frame, channels) {
  if (!rnnoise) return frame;

  try {
    const SAMPLES_PER_CHANNEL = 480;
    const out = Buffer.alloc(frame.length);

    for (let ch = 0; ch < channels; ch++) {
      // Extract channel samples as Float32 (normalised to [-1, 1])
      const f32 = new Float32Array(SAMPLES_PER_CHANNEL);
      for (let i = 0; i < SAMPLES_PER_CHANNEL; i++) {
        const byteIdx = (i * channels + ch) * 2;
        f32[i] = frame.readInt16LE(byteIdx) / 32768.0;
      }

      // Process with RNNoise
      rnnoise.processFrame(f32);  // modifies in-place

      // Write back as 16-bit PCM
      for (let i = 0; i < SAMPLES_PER_CHANNEL; i++) {
        const s = Math.max(-1, Math.min(1, f32[i]));
        out.writeInt16LE(Math.round(s * 32767), (i * channels + ch) * 2);
      }
    }
    return out;
  } catch (e) {
    log('warn', `RNNoise frame error: ${e.message}`);
    return frame; // return unprocessed on error
  }
}

module.exports = AudioPipeline;
