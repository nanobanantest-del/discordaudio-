'use strict';

/**
 * Discord Voice Recorder Bot
 * Production-ready bot with noise suppression, diarization, and MP3 output.
 */

require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection, VoiceConnectionStatus, entersState } = require('@discordjs/voice');
const path = require('path');
const fs = require('fs');

const RecordingSession = require('./RecordingSession');
const { log } = require('./logger');

// ─── Validate Environment ────────────────────────────────────────────────────
const REQUIRED_ENV = ['DISCORD_TOKEN', 'CLIENT_ID'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    console.error(`[FATAL] Missing required env variable: ${key}`);
    process.exit(1);
  }
}

// ─── Client Setup ────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

// Map<guildId, RecordingSession>
const sessions = new Collection();

// ─── Ready ───────────────────────────────────────────────────────────────────
client.once('clientReady', (c) => {
  log('info', `Logged in as ${c.user.tag}`);
});

// ─── Interaction Handler ─────────────────────────────────────────────────────
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName, guildId, member, guild } = interaction;

  // ── /join ──────────────────────────────────────────────────────────────────
  if (commandName === 'join') {
    const voiceChannel = member.voice?.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: '❌ You must be in a voice channel first.', ephemeral: true });
    }

    try {
      const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId,
        adapterCreator: guild.voiceAdapterCreator,
        selfDeaf: false,   // must hear users
        selfMute: true,    // bot doesn't speak
      });

      await entersState(connection, VoiceConnectionStatus.Ready, 10_000);
      log('info', `[${guildId}] Joined voice channel: ${voiceChannel.name}`);
      await interaction.reply({ content: `✅ Joined **${voiceChannel.name}**. Use \`/record\` to start recording.`, ephemeral: false });
    } catch (err) {
      log('error', `Join failed: ${err.message}`);
      await interaction.reply({ content: `❌ Could not join the voice channel: ${err.message}`, ephemeral: true });
    }
  }

  // ── /record ────────────────────────────────────────────────────────────────
  else if (commandName === 'record') {
    // Permission gate
    if (!member.permissions.has('ManageGuild')) {
      return interaction.reply({ content: '🔒 You need **Manage Server** permission to start a recording.', ephemeral: true });
    }

    const connection = getVoiceConnection(guildId);
    if (!connection) {
      return interaction.reply({ content: '❌ Bot is not in a voice channel. Use `/join` first.', ephemeral: true });
    }

    if (sessions.has(guildId)) {
      return interaction.reply({ content: '⚠️ A recording is already in progress.', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      const session = new RecordingSession(guildId, connection, interaction);
      sessions.set(guildId, session);

      session.on('ended', () => sessions.delete(guildId));
      await session.start();

      await interaction.editReply('🔴 **Recording has started.** Users in the channel have been notified.');

      // Notify in the text channel associated with the voice channel (if any)
      const voiceChannel = guild.channels.cache.get(connection.joinConfig.channelId);
      if (voiceChannel?.guild?.systemChannel) {
        voiceChannel.guild.systemChannel.send('🔴 **Recording has started** in ' + voiceChannel.name + '. Participants are aware.').catch(() => {});
      }

      // Also send in the interaction channel
      interaction.channel?.send('🔴 **Recording has started.** All voices in the channel are being captured.').catch(() => {});

    } catch (err) {
      sessions.delete(guildId);
      log('error', `Record start failed: ${err.message}`);
      await interaction.editReply(`❌ Failed to start recording: ${err.message}`);
    }
  }

  // ── /stop ──────────────────────────────────────────────────────────────────
  else if (commandName === 'stop') {
    if (!member.permissions.has('ManageGuild')) {
      return interaction.reply({ content: '🔒 You need **Manage Server** permission to stop a recording.', ephemeral: true });
    }

    const session = sessions.get(guildId);
    if (!session) {
      return interaction.reply({ content: '⚠️ No recording is currently in progress.', ephemeral: true });
    }

    await interaction.deferReply();
    try {
      await session.stop();
      await interaction.editReply('⏹️ Recording stopped. Processing audio… Results will be sent via DM.');
    } catch (err) {
      log('error', `Stop failed: ${err.message}`);
      await interaction.editReply(`❌ Error stopping recording: ${err.message}`);
    }
  }
});

// ─── Graceful Shutdown ───────────────────────────────────────────────────────
async function shutdown(signal) {
  log('info', `Received ${signal}. Stopping all active sessions…`);
  for (const [guildId, session] of sessions) {
    try { await session.stop(); } catch (_) {}
  }
  client.destroy();
  process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// ─── Login ───────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN);
