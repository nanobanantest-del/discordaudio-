'use strict';

/**
 * logger.js — Minimal structured logger with timestamps.
 * Writes to stdout (info/debug) and stderr (warn/error).
 */

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const MIN_LEVEL = LEVELS[process.env.LOG_LEVEL ?? 'info'] ?? 1;

function log(level, message) {
  if ((LEVELS[level] ?? 1) < MIN_LEVEL) return;
  const ts  = new Date().toISOString();
  const out = `[${ts}] [${level.toUpperCase().padEnd(5)}] ${message}`;
  if (level === 'error' || level === 'warn') {
    process.stderr.write(out + '\n');
  } else {
    process.stdout.write(out + '\n');
  }
}

module.exports = { log };
