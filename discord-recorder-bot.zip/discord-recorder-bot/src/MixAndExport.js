'use strict';

/**
 * MixAndExport.js
 * Converts per-user raw PCM to:
 *   1. clean_<userId>.mp3  — noise-suppressed, normalised per user
 *   2. final_mix.mp3       — all users mixed together with timestamps
 *
 * Uses FFmpeg for:
 *   - Noise reduction (arnndn / anlmdn) when RNNoise native is unavailable
 *   - Loudness normalisation (loudnorm EBU R128)
 *   - MP3 encoding (libmp3lame 192k)
 *   - Audio mixing (amix)
 */

const path           = require('path');
const fs             = require('fs');
const { execFile }   = require('child_process');
const { promisify }  = require('util');
const ffmpegPath     = require('ffmpeg-static');
const { AttachmentBuilder } = require('discord.js');
const { log }        = require('./logger');

const execFileAsync = promisify(execFile);

// RNNoise AR model bundled with FFmpeg (libavfilter arnndn)
// Falls back to anlmdn (non-local-means denoiser) if arnndn is unavailable
const FFMPEG_NR_FILTER = `arnndn=m='${path.join(__dirname, '..', 'models', 'rnnoise_bd.rnnn')}'`;
const FFMPEG_NR_FALLBACK = "anlmdn=s=7:p=0.002:r=0.002:t=0.002";

class MixAndExport {
  /**
   * @param {string} outputDir
   * @param {Map<string, import('./AudioPipeline')>} pipelines
   * @param {Map<string, Array<{start:number, end:number|null}>>} speakEvents
   * @param {{ sampleRate, channels, bytesPerSample, startTime }} opts
   */
  constructor(outputDir, pipelines, speakEvents, opts) {
    this.outputDir    = outputDir;
    this.pipelines    = pipelines;
    this.speakEvents  = speakEvents;
    this.sampleRate   = opts.sampleRate    ?? 48_000;
    this.channels     = opts.channels      ?? 2;
    this.bytesPerSample = opts.bytesPerSample ?? 2;
    this.startTime    = opts.startTime;
  }

  /**
   * Run the full export pipeline.
   * @returns {{ users: string[], attachments: import('discord.js').AttachmentBuilder[] }}
   */
  async run() {
    const userMp3s = [];
    const usersProcessed = [];

    for (const [userId, pipeline] of this.pipelines) {
      if (!pipeline.hasAudio) {
        log('info', `Skipping ${userId} — no audio captured`);
        continue;
      }

      const pcmPath = pipeline.pcmPath;
      const mp3Path = path.join(this.outputDir, `clean_${userId}.mp3`);

      try {
        await this._pcmToMp3(pcmPath, mp3Path, userId);
        userMp3s.push({ userId, mp3Path });
        usersProcessed.push(userId);
        log('info', `Exported ${path.basename(mp3Path)}`);
      } catch (err) {
        log('error', `Failed to export ${userId}: ${err.message}`);
      }
    }

    // Build final mix
    const mixPath = path.join(this.outputDir, 'final_mix.mp3');
    let mixOk = false;
    if (userMp3s.length > 0) {
      try {
        await this._mixToMp3(userMp3s.map(u => u.mp3Path), mixPath);
        log('info', 'Final mix exported');
        mixOk = true;
      } catch (err) {
        log('error', `Mix failed: ${err.message}`);
      }
    }

    // Build Discord attachment list
    const attachments = [];
    for (const { userId, mp3Path } of userMp3s) {
      if (fs.existsSync(mp3Path)) {
        attachments.push(new AttachmentBuilder(mp3Path, { name: `clean_${userId}.mp3` }));
      }
    }
    if (mixOk && fs.existsSync(mixPath)) {
      attachments.push(new AttachmentBuilder(mixPath, { name: 'final_mix.mp3' }));
    }

    return { users: usersProcessed, attachments };
  }

  // ─── Private ───────────────────────────────────────────────────────────────

  /**
   * Convert raw PCM → noise-suppressed, normalised MP3.
   * Applies FFmpeg NR filter when RNNoise native is not active.
   */
  async _pcmToMp3(pcmPath, mp3Path, userId) {
    const useRNNoise = _rnnoiseLoaded();

    // Build filter chain
    // When RNNoise is active the PCM is already clean → only normalise
    // When RNNoise is not active → apply FFmpeg noise reduction then normalise
    let filterChain;
    if (useRNNoise) {
      // Only loudness normalisation
      filterChain = 'loudnorm=I=-16:TP=-1.5:LRA=11';
    } else {
      // Noise reduction + normalise
      // Try arnndn first; anlmdn as fallback (both are inside ffmpeg)
      filterChain = `${FFMPEG_NR_FALLBACK},loudnorm=I=-16:TP=-1.5:LRA=11`;
    }

    const args = [
      '-y',                             // overwrite output
      '-f', 's16le',                    // input format: signed 16-bit LE PCM
      '-ar', String(this.sampleRate),   // sample rate
      '-ac', String(this.channels),     // channels
      '-i', pcmPath,                    // input file
      '-af', filterChain,               // audio filter chain
      '-c:a', 'libmp3lame',             // MP3 codec
      '-b:a', '192k',                   // bitrate
      '-id3v2_version', '3',
      '-metadata', `title=User ${userId}`,
      mp3Path,
    ];

    try {
      await _ffmpeg(args);
    } catch (err) {
      // If arnndn model not found, retry with anlmdn only
      if (err.message.includes('arnndn') || err.message.includes('No such file')) {
        log('warn', `arnndn failed for ${userId}, retrying with anlmdn`);
        const fallbackArgs = args.map(a => a.includes('arnndn') ? FFMPEG_NR_FALLBACK + ',loudnorm=I=-16:TP=-1.5:LRA=11' : a);
        await _ffmpeg(fallbackArgs);
      } else {
        throw err;
      }
    }
  }

  /**
   * Mix multiple MP3s into one using amix.
   * Uses `amerge` for alignment and `amix` with normalization.
   */
  async _mixToMp3(mp3Paths, outPath) {
    const inputArgs = [];
    const filterParts = [];

    for (let i = 0; i < mp3Paths.length; i++) {
      inputArgs.push('-i', mp3Paths[i]);
      filterParts.push(`[${i}:a]`);
    }

    // amix: mix all inputs, normalize volume, drop on shortest
    const filterStr = `${filterParts.join('')}amix=inputs=${mp3Paths.length}:duration=longest:normalize=1[out]`;

    const args = [
      '-y',
      ...inputArgs,
      '-filter_complex', filterStr,
      '-map', '[out]',
      '-c:a', 'libmp3lame',
      '-b:a', '192k',
      outPath,
    ];

    await _ffmpeg(args);
  }
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function _rnnoiseLoaded() {
  try { require('rnnoise'); return true; } catch (_) { return false; }
}

/**
 * Run FFmpeg with given args, streaming stderr to logger.
 * @param {string[]} args
 */
function _ffmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = require('child_process').spawn(ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('close', (code) => {
      if (code === 0) return resolve();
      reject(new Error(`FFmpeg exited ${code}: ${stderr.slice(-500)}`));
    });
    proc.on('error', reject);
  });
}

module.exports = MixAndExport;
