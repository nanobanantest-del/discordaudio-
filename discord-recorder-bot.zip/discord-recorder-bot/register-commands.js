'use strict';

/**
 * register-commands.js
 * Run once to register slash commands with Discord.
 *
 * Usage:
 *   node register-commands.js           — registers globally (up to 1 hour to propagate)
 *   node register-commands.js <guildId> — registers to a specific guild (instant)
 */

require('dotenv').config();
const { REST, Routes, ApplicationCommandOptionType } = require('discord.js');

const TOKEN     = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID  = process.argv[2]; // optional

if (!TOKEN || !CLIENT_ID) {
  console.error('[FATAL] DISCORD_TOKEN and CLIENT_ID must be set in .env');
  process.exit(1);
}

// ─── Command Definitions ────────────────────────────────────────────────────
const commands = [
  {
    name        : 'join',
    description : 'Bot joins your current voice channel.',
  },
  {
    name        : 'record',
    description : 'Start recording the voice channel (requires Manage Server permission).',
    options     : [
      {
        name        : 'auto_stop',
        description : 'Auto-stop after N seconds of silence (default: 30)',
        type        : ApplicationCommandOptionType.Integer,
        required    : false,
        min_value   : 5,
        max_value   : 300,
      },
    ],
  },
  {
    name        : 'stop',
    description : 'Stop the current recording and receive the MP3 output via DM.',
  },
];

// ─── Register ────────────────────────────────────────────────────────────────
const rest = new REST({ version: '10' }).setToken(TOKEN);

(async () => {
  try {
    console.log(`Registering ${commands.length} slash command(s)…`);

    let data;
    if (GUILD_ID) {
      // Guild-specific (instant)
      data = await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
      console.log(`✅ Registered ${data.length} commands to guild ${GUILD_ID}`);
    } else {
      // Global (takes up to 1 hour to propagate)
      data = await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
      console.log(`✅ Registered ${data.length} commands globally. May take up to 1 hour to appear.`);
    }
  } catch (err) {
    console.error('Registration failed:', err);
    process.exit(1);
  }
})();
