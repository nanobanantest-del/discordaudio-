# 🎙️ Discord Voice Recorder Bot

Production-ready Discord bot that records voice channels, applies **noise suppression**, performs basic **speaker diarization**, normalises volume, and delivers clean **MP3 files** via DM.

---

## ✨ Features

| Feature | Details |
|---|---|
| `/join` | Bot joins your voice channel |
| `/record` | Starts recording (Manage Server permission required) |
| `/stop` | Stops recording, processes & DMs you the MP3s |
| Noise Suppression | RNNoise (native, preferred) or FFmpeg `anlmdn` filter |
| Volume Normalisation | EBU R128 loudness normalisation via FFmpeg `loudnorm` |
| Speaker Diarization | Per-user timestamps logged and included in DM |
| Auto-stop on silence | Configurable silence threshold (default 30 s) |
| Per-user MP3 | `clean_<userId>.mp3` for every speaker |
| Final mix | `final_mix.mp3` — all speakers merged |
| Low RAM | Streams audio directly to disk; no large in-memory buffers |

---

## 🖥️ Requirements

- **Node.js ≥ 18**
- **FFmpeg** (bundled via `ffmpeg-static` — no system install needed)
- A Discord Application with a Bot token

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/yourname/discord-recorder-bot
cd discord-recorder-bot
npm install
```

> ⚠️ `sodium-native` requires `node-gyp`. On Ubuntu/Debian run:
> ```bash
> sudo apt install build-essential python3
> ```
> On Windows install [Windows Build Tools](https://github.com/nodejs/node-gyp#on-windows).

---

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and fill in DISCORD_TOKEN and CLIENT_ID
```

Get these values from [Discord Developer Portal](https://discord.com/developers/applications):
- `DISCORD_TOKEN` → Bot → Reset Token
- `CLIENT_ID` → General Information → Application ID

**Required Bot Permissions & Intents:**
- Gateway Intents: `GUILDS`, `GUILD_VOICE_STATES`, `GUILD_MESSAGES`, `DIRECT_MESSAGES`
- OAuth2 Scopes: `bot`, `applications.commands`
- Bot Permissions: `Connect`, `Speak`, `Send Messages`, `Read Message History`

---

### 3. Register Slash Commands

```bash
# For instant registration to a specific guild (recommended during dev):
node register-commands.js YOUR_GUILD_ID

# For global registration (takes up to 1 hour to propagate):
node register-commands.js
```

---

### 4. Start the Bot

```bash
npm start
```

---

## 🔊 Noise Suppression Details

The bot uses a two-tier noise suppression system:

### Tier 1 — RNNoise (Preferred)

RNNoise is a deep learning-based noise suppressor that gives best results.

**Install the optional native addon:**

```bash
npm install rnnoise
```

If `rnnoise` is installed, it is automatically used for real-time, frame-by-frame noise suppression in the audio pipeline.

### Tier 2 — FFmpeg `anlmdn` (Automatic Fallback)

If RNNoise is not installed, the bot automatically falls back to FFmpeg's Non-Local Means Denoiser (`anlmdn`) applied during the MP3 export step. Quality is slightly lower but works out of the box.

---

## ⚙️ Configuration

All options are set via `.env`:

| Variable | Default | Description |
|---|---|---|
| `DISCORD_TOKEN` | **required** | Your bot token |
| `CLIENT_ID` | **required** | Your bot's Application ID |
| `SILENCE_THRESHOLD_MS` | `30000` | Auto-stop after N ms of silence |
| `MAX_RECORDING_MS` | `3600000` | Hard cap on recording (1 hour) |
| `LOG_LEVEL` | `info` | `debug` / `info` / `warn` / `error` |

---

## 📁 Output Files

After `/stop`, the invoker receives a DM with:

```
clean_<userId1>.mp3   — Noise-suppressed, normalised audio for user 1
clean_<userId2>.mp3   — Noise-suppressed, normalised audio for user 2
...
final_mix.mp3         — All users mixed together
```

Plus a speaker diarization summary:
```
• @Alice: 00:03–00:45, 01:12–02:30
• @Bob:   00:15–01:00
```

---

## 🏗️ Project Structure

```
discord-recorder-bot/
├── src/
│   ├── bot.js             # Entry point, command routing
│   ├── RecordingSession.js # Session lifecycle, speaker subscription
│   ├── AudioPipeline.js    # Per-user Opus→PCM→(RNNoise)→disk
│   ├── MixAndExport.js     # FFmpeg NR, normalisation, MP3 export, mix
│   └── logger.js           # Structured logger
├── register-commands.js    # Slash command registration script
├── package.json
├── .env.example
└── README.md
```

---

## 🔒 Permissions & Compliance

- Only users with **Manage Server** can start/stop recordings.
- A visible message **"🔴 Recording has started"** is posted in the server when recording begins, ensuring all participants are aware per [Discord ToS §2.9](https://discord.com/terms).
- No audio data is stored beyond the current session — temp files are deleted after delivery.

---

## 🐛 Troubleshooting

| Problem | Fix |
|---|---|
| `ERR_DLOPEN_FAILED` on sodium | Run `npm rebuild sodium-native` |
| `Cannot find module 'prism-media'` | `npm install prism-media` |
| Bot joins but records silence | Ensure bot is **not** self-deafened (check `selfDeaf: false`) |
| DM not received | Enable DMs from server members in Privacy Settings |
| `rnnoise` build fails | Skip it — FFmpeg fallback is automatic |
| FFmpeg error on mix | Check available disk space in `/tmp` |

---

## 📄 License

MIT
